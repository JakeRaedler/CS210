/*
Jake Raedler
01/28/2024
Clock 
*/
#include <iostream>
#include <iomanip> 
#include <string>
#include <sstream>
#include <algorithm>

std::string twoDigitString(unsigned int n) {
	//stringstream converts a number to a string
	std::stringstream ss;

	//Check if value is less than 10
	if (n < 10) {
		//If the value is less than 10, this adds a 0 to front of the number
		ss << '0';

	}
	//Add number to stringtream	
	ss << n;

	//Convert the stringstream to a string and return
	return ss.str();

}

//Using the string constructor to create a string of length n with character c
std::string nCharString(size_t n, char c) {
	return std::string(n, c);
}

//Military time format
std::string formatTime24(unsigned int h, unsigned int m, unsigned int s) {
	std::string formattedHours = twoDigitString(h);
	std::string formattedMinutes = twoDigitString(m);
	std::string formattedSeconds = twoDigitString(s);

	//Displays the information in the correct format when called
	std::string formattedTime = formattedHours + ":" + formattedMinutes + ":" + formattedSeconds;

	return formattedTime;

}

//Twelve-hour time format
std::string formatTime12(unsigned int h, unsigned int m, unsigned int s) {
	// Adjust the hours for 12-hour format
	unsigned int formattedHours = (h % 12 == 0) ? 12 : h % 12;

	//Determine if A.M. or P.M.
	std::string amOrPm = (h < 12) ? "A M" : "P M";

	//Format using twoDigitString
	std::string formattedHoursStr = twoDigitString(formattedHours);
	std::string formattedMinutesStr = twoDigitString(m);
	std::string formattedSecondsStr = twoDigitString(s);

	//Concatenate the formatted components with colons and amOrPm
	std::string formattedTime = formattedHoursStr + ":" + formattedMinutesStr + ":" +formattedSecondsStr + " " + amOrPm;

	return formattedTime;
}

void displayClocks(unsigned int h, unsigned int m, unsigned int s) {
    // Line 1
    std::cout << nCharString(27, '*') << nCharString(3, ' ') << nCharString(27, '*') << std::endl;

    // Line 2
    std::cout << '*' << nCharString(6, ' ') << "12-HOUR CLOCK" << nCharString(6, ' ') << '*' << nCharString(3, ' ');
    std::cout << '*' << nCharString(6, ' ') << "24-HOUR CLOCK" << nCharString(6, ' ') << '*' << std::endl;

    // Line 3
    std::cout << std::endl; // Blank line

    // Line 4
    std::cout << '*' << nCharString(6, ' ') << formatTime12(h, m, s) << nCharString(7, ' ') << '*';
    std::cout << nCharString(3, ' ') << '*' << nCharString(8, ' ') << formatTime24(h, m, s) << nCharString(9, ' ') << '*' << std::endl;

    // Line 5
    std::cout << nCharString(27, '*') << nCharString(3, ' ') << nCharString(27, '*') << std::endl;
}

unsigned int gHour = 0;
unsigned int gMinute = 0;
unsigned int gSecond = 0;

// Function to set the hour
void setHour(unsigned int h) {
	gHour = h;
}

// Function to get the current hour
unsigned int getHour() {
	return gHour;
}

// Function to set the minute
void setMinute(unsigned int m) {
	gMinute = m;
}

// Function to get the current minute
unsigned int getMinute() {
	return gMinute;
}

// Function to set the second
void setSecond(unsigned int s) {
	gSecond = s;
}

// Function to get the current second
unsigned int getSecond() {
	return gSecond;
}

int getMenuChoice()
{
	return 0;
}
//Function for adding one hour
void addOneHour() {
	unsigned int currentHour = getHour();

	if (currentHour >= 0 && currentHour < 23) {
		setHour(currentHour + 1);
	}
	else if (currentHour == 23) {
		setHour(0);
	}
	
}


unsigned int getMenuChoice(unsigned int maxChoice) {
	unsigned int choice;

	// Repeat until a valid choice is entered
	do {
		// Prompt user for input
		std::cin >> choice;

		// Clear input buffer in case of invalid input
		std::cin.clear();
		std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

	} while (choice < 1 || choice > maxChoice);

	return choice;
}

// Function prototypes
int getMenuChoice();
void addOneHour();
//Function for adding one minute
void addOneMinute() {
	unsigned int currentMinute = getMinute();

	if (currentMinute >= 0 && currentMinute < 59) {
		setMinute(currentMinute + 1);
	}
	else if (currentMinute == 59) {
		setMinute(0);
		// Increment hour when minutes wrap around
		addOneHour();
	}

}
//Function for adding one second
void addOneSecond() {
	unsigned int currentSecond = getSecond();

	if (currentSecond >= 0 && currentSecond < 59) {
		setSecond(currentSecond + 1);
	}
	else if (currentSecond == 59) {
		setSecond(0);
		// Increment minute when seconds wrap around
		addOneMinute();
	}

}

void printMenu(char* strings[], unsigned int numStrings, unsigned char width) {
	// Print width *'s followed by an endl
	std::cout << nCharString(width, '*') << std::endl;

	for (unsigned int i = 0; i < numStrings; ++i) {
		// Calculate the number of spaces needed to align with the right side
		size_t numSpaces = width - 7 - std::to_string(i + 1).length() - std::string(strings[i]).length();

		// Print each line with the correct format
		std::cout << "* " << i + 1 << " - " << strings[i] << std::left << std::setw(numSpaces) << ' ' << " *" << std::endl;

		// Skip a line after each line except the last line
		if (i < numStrings - 1) {
			std::cout << std::endl;
		}
	}

	// Print another width *'s followed by an endl
	std::cout << nCharString(width, '*') << std::endl;
}

int main() {
	unsigned int initialHour, initialMinute, initialSecond;
	std::string amOrPm;

	// Get user input for initial time
	std::cout << "Enter initial hour (0-12): ";
	std::cin >> initialHour;

	std::cout << "Enter initial minute (0-59): ";
	std::cin >> initialMinute;

	std::cout << "Enter initial second (0-59): ";
	std::cin >> initialSecond;

	// Validate the input
	if (initialHour >= 0 && initialHour <= 12 && initialMinute >= 0 && initialMinute <= 59 && initialSecond >= 0 && initialSecond <= 59) {
		// Prompt user for AM or PM
		std::cout << "Enter AM or PM: ";
		std::cin >> amOrPm;

		// Convert input to uppercase for case-insensitivity
		std::transform(amOrPm.begin(), amOrPm.end(), amOrPm.begin(), ::toupper);

		if (amOrPm == "AM" || amOrPm == "PM") {
			// Adjust the hour based on AM or PM
			if (amOrPm == "PM") {
				initialHour += 12;
			}

			// Set the initial time
			setHour(initialHour);
			setMinute(initialMinute);
			setSecond(initialSecond);

			// Display the initial clocks
			displayClocks(getHour(), getMinute(), getSecond());

			int choice;

			do {
				const char* menuStrings[] = {
					"Add One Hour",
					"Add One Minute",
					"Add One Second",
					"Exit"
				};

				constexpr unsigned int menuSize = sizeof(menuStrings) / sizeof(menuStrings[0]);

				// Display the menu
				printMenu(const_cast<char**>(menuStrings), menuSize, 50); 

				choice = getMenuChoice(4); 

				// Take action based on user choice
				switch (choice) {
				case 1:
					addOneHour();
					break;
				case 2:
					addOneMinute();
					break;
				case 3:
					addOneSecond();
					break;
				case 4:
					// No need for any specific action when exiting
					break;
				default:
					// getMenuChoice should handle invalid choices, but I included a default case for additional safety
					break;
				}

				// Update and display clocks after each user action
				displayClocks(getHour(), getMinute(), getSecond());

			} while (choice != 4);
		}
		else {
			std::cout << "Invalid input for AM or PM. Exiting program." << std::endl;
		}
	}
	else {
		std::cout << "Invalid input for initial time. Exiting program." << std::endl;
	}

	return 0;
}